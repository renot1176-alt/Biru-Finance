package com.birufinance.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.widget.Toast;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(7,17,39));
    getWindow().setNavigationBarColor(Color.rgb(7,17,39));
    if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(0);
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(7,17,39));
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true); s.setAllowFileAccess(true);
    s.setAllowContentAccess(false); s.setSupportZoom(false);
    s.setMediaPlaybackRequiresUserGesture(false);
    web.addJavascriptInterface(new Bridge(), "BiruNative");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  public class Bridge {
    @JavascriptInterface public void toast(String msg) {
      runOnUiThread(()->Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show());
    }
    @JavascriptInterface public String appVersion(){ return "2.0.0"; }
    @JavascriptInterface public void shareText(String text) {
      runOnUiThread(()->{
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT,text);
        startActivity(Intent.createChooser(i,"Bagikan data BiruFinance"));
      });
    }
  }
  @Override public void onBackPressed() {
    if(web!=null) web.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack()",null);
    else super.onBackPressed();
  }
}
