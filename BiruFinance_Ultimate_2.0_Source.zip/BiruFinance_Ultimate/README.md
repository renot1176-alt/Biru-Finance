# BiruFinance Ultimate 2.0

Aplikasi pencatatan keuangan pribadi Android yang bekerja offline. Proyek ini menggunakan Android WebView untuk antarmuka lokal (HTML/CSS/JavaScript) dan menyimpan data pada `localStorage` WebView perangkat.

## Fitur yang tersedia
- Dashboard saldo dompet, pemasukan/pengeluaran, grafik arus kas dan transaksi terbaru.
- Pencatatan pemasukan dan pengeluaran, kategori, catatan, tanggal, edit dan hapus.
- Multi-dompet, saldo per dompet, transfer antar-dompet.
- Anggaran bulanan per kategori dan progres pemakaian.
- Target tabungan dan penambahan dana target.
- Laporan enam bulan dan ringkasan kategori.
- Kalkulator dasar, persentase, riwayat perhitungan dan memasukkan hasil ke form transaksi.
- Ekspor transaksi CSV, backup dan pemulihan JSON.
- Navigasi swipe, efek suara pembuka orisinal, feedback suara tombol, ikon aplikasi.
- Semua aset antarmuka disimpan lokal; tidak ada API atau koneksi server.

## Build APK melalui GitHub
1. Buat repository GitHub baru atau gunakan repository proyek BiruFinance.
2. Upload seluruh isi folder proyek ini (bukan folder induknya) ke branch `main`.
3. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
4. Buka tab **Actions**. Workflow **Build BiruFinance APK** berjalan otomatis setelah push, atau jalankan manual melalui **Run workflow**.
5. Setelah workflow sukses, buka hasil run dan unduh artifact `BiruFinance-Ultimate-APK`.
6. Ekstrak ZIP artifact lalu pasang `app-debug.apk` di Android.

Build memerlukan Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.9 dan Java 17; workflow mengaturnya otomatis.

## Catatan penting
- File yang dihasilkan workflow adalah APK debug untuk pengujian/pemasangan pribadi, bukan APK release bertanda tangan untuk distribusi Play Store.
- Data aplikasi disimpan pada penyimpanan lokal WebView. Backup JSON sebelum menghapus aplikasi, membersihkan data aplikasi, atau pindah perangkat.
- Transfer antar-dompet mengubah saldo dompet, bukan transaksi pemasukan/pengeluaran.
- Kalkulator menggunakan ekspresi aritmetika dasar dan persentase.
- Ukuran APK bergantung pada proses build dan kompresi Android; ukuran file bukan ukuran RAM yang digunakan aplikasi.
- Tidak ada klaim bahwa APK sudah teruji pada perangkat fisik sebelum kamu menjalankan build dan menginstalnya.

## Struktur
- `app/src/main/java/.../MainActivity.java`: shell Android dan jembatan native minimal.
- `app/src/main/assets/index.html`: halaman dan komponen aplikasi.
- `app/src/main/assets/style.css`: gaya Liquid Glass.
- `app/src/main/assets/app.js`: logika transaksi, dompet, anggaran, laporan, kalkulator dan backup.
- `app/src/main/assets/intro_soundtrack.wav`: soundtrack pembuka orisinal.
- `.github/workflows/build-apk.yml`: pipeline build APK.

## Privasi
BiruFinance tidak mengirim data ke internet. Backup yang diekspor berisi data keuangan pribadi; simpan di lokasi yang aman dan jangan membagikannya sembarangan.
