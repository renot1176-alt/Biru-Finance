# Asset notes
- `aurora_bg.jpg`: original locally generated blue aurora background texture, used by app stylesheet.
- `intro_soundtrack.wav`: original synthesized short ambient opening sound, bundled for offline playback.
- Launcher icons: generated BiruFinance wallet mark at Android density sizes.
No remote fonts, trackers, analytics, or runtime CDN dependencies are used.
