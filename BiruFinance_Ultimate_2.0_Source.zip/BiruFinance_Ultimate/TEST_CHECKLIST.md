# Checklist pengujian manual

- [ ] Jalankan workflow GitHub Actions dan pastikan `assembleDebug` sukses.
- [ ] Instal APK pada Android 6+.
- [ ] Tambah pemasukan dan cek saldo dompet bertambah.
- [ ] Tambah pengeluaran dan cek saldo dompet berkurang.
- [ ] Edit transaksi dan pastikan saldo dihitung ulang.
- [ ] Hapus transaksi dan pastikan saldo dipulihkan.
- [ ] Transfer antar-dompet dan pastikan kedua saldo berubah.
- [ ] Tambah anggaran dan catat pengeluaran pada kategori yang sama.
- [ ] Tambah target tabungan dan lakukan kontribusi.
- [ ] Hitung operasi dasar dan persentase pada kalkulator.
- [ ] Masukkan hasil kalkulator ke form transaksi.
- [ ] Ekspor CSV dan backup JSON.
- [ ] Hapus data uji, pulihkan backup, dan cek data kembali.
- [ ] Tutup dan buka ulang aplikasi untuk memastikan penyimpanan lokal bertahan.
- [ ] Uji navigasi swipe dan tombol kembali Android.
