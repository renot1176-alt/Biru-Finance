'use strict';
const KEY='birufinance_ultimate_v3';
const LEGACY_KEY='birufinance_ultimate_v2';
const cats={expense:['🍜 Makanan','🚗 Transportasi','🛍 Belanja','🏠 Rumah','💡 Tagihan','💊 Kesehatan','🎮 Hiburan','📚 Pendidikan','☕ Jajan','📦 Lainnya'],income:['💼 Gaji','🎁 Hadiah','📈 Investasi','🧾 Bonus','🛒 Penjualan','💰 Lainnya']};
const $=id=>document.getElementById(id),id=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const monthKey=(s=today())=>String(s).slice(0,7);
const rupiah=n=>'Rp'+Math.round(Number(n)||0).toLocaleString('id-ID');
const parseMoney=v=>Number(String(v??'').replace(/[^0-9]/g,''))||0;
const formatMoneyValue=v=>{const n=parseMoney(v);return n?n.toLocaleString('id-ID'):''};
function bindMoneyInput(el){if(!el||el.dataset.moneyBound)return;el.dataset.moneyBound='1';el.addEventListener('input',()=>{const start=el.selectionStart??el.value.length,old=el.value.length;el.value=formatMoneyValue(el.value);const delta=el.value.length-old;try{el.setSelectionRange(Math.max(0,start+delta),Math.max(0,start+delta))}catch{}})}
function setMoneyInput(el,value){if(el)el.value=formatMoneyValue(value)}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sum=a=>a.reduce((t,x)=>t+(Number(x.amount)||0),0);
const defaults=()=>({wallets:[{id:id(),name:'Dompet Utama',balance:0,emoji:'👛'},{id:id(),name:'Bank',balance:0,emoji:'🏦'}],tx:[],transfers:[],budgets:[],goals:[],settings:{sound:true,vibrate:true,hideBalance:false,themeMode:'light',backgroundColor:'#176fc9',surfaceColor:'#eaf4ff',fontColor:'#102c55',},calcHistory:[]});
function migrateOldFormat(old){const d=defaults(),wallet=d.wallets[0];wallet.balance=Math.max(0,Number(old.opening)||0);const transfers=[];const tx=(old.tx||[]).filter(x=>x.type==='income'||x.type==='expense').map(x=>{const amount=Math.round(Number(x.amount)||0);wallet.balance+=x.type==='income'?amount:-amount;return{id:x.id||id(),type:x.type,amount,category:String(x.category||'📦 Lainnya'),note:String(x.desc||x.note||x.category||'Transaksi'),date:x.date||today(),walletId:wallet.id,created:Date.now()}});(old.tx||[]).filter(x=>x.type==='transfer').forEach(x=>transfers.push({id:x.id||id(),from:null,to:null,label:String(x.desc||x.category||'Transfer lama'),amount:Number(x.amount)||0,date:x.date||today(),created:Date.now()}));d.tx=tx;d.transfers=transfers;d.budgets=(old.budgets||[]).map(x=>({id:id(),category:String(x.category||x.name||'📦 Lainnya'),limit:Number(x.limit)||0})).filter(x=>x.limit>0);d.goals=(old.goals||[]).map(x=>({id:id(),name:String(x.name||'Target tabungan'),target:Number(x.target)||0,saved:Number(x.saved)||0})).filter(x=>x.target>0);return d}
let state;try{const current=localStorage.getItem(KEY),v2=localStorage.getItem(LEGACY_KEY),old=localStorage.getItem('biru-finance-complete-v2');state=current?JSON.parse(current):(v2?JSON.parse(v2):(old?migrateOldFormat(JSON.parse(old)):defaults()));}catch{state=defaults()}
state={...defaults(),...state};state.settings={sound:true,vibrate:true,hideBalance:false,themeMode:'light',backgroundColor:'#176fc9',surfaceColor:'#eaf4ff',fontColor:'#102c55',...state.settings};state.transfers=state.transfers||[];state.tx=state.tx||[];state.wallets=state.wallets||[];state.budgets=state.budgets||[];state.goals=state.goals||[];state.calcHistory=state.calcHistory||[];
let filter='all',txType='expense',editing=null,budgetEditing=null,calcExpr='',calcResult=0,calcJust=false,activePage='home',swipeStart=null,reportMonthSelected=null;
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),2200);if(state.settings.vibrate&&navigator.vibrate)navigator.vibrate(12)}
function beep(){if(!state.settings.sound)return;try{const c=new(window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=520;g.gain.setValueAtTime(.04,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.1);o.start();o.stop(c.currentTime+.11);o.onended=()=>c.close()}catch{}}
function go(page){const el=$(page);if(!el)return;activePage=page;document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===page));document.querySelectorAll('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===page));render();window.scrollTo({top:0,behavior:'smooth'});beep()}
function txOf(type,month=null){return state.tx.filter(x=>x.type===type&&(!month||monthKey(x.date)===month))}
function walletTotal(){return sum(state.wallets.map(w=>({amount:w.balance})))}
function totals(month=monthKey()){return {income:sum(txOf('income',month)),expense:sum(txOf('expense',month)),wallet:walletTotal(),saved:sum(state.goals.map(g=>({amount:g.saved||0})))}}
function shownMoney(n){return state.settings.hideBalance?'••••••':rupiah(n)}
function render(){applyAppearance();const t=totals();$('totalBalance').textContent=shownMoney(t.wallet);$('goalTotal').textContent=shownMoney(t.saved);$('goalTotalPage').textContent=shownMoney(t.saved);$('incomeTotal').textContent=shownMoney(t.income);$('expenseTotal').textContent=shownMoney(t.expense);$('settingsBalance').textContent=rupiah(t.wallet);$('soundToggle').checked=state.settings.sound;$('vibeToggle').checked=state.settings.vibrate;$('hideToggle').checked=state.settings.hideBalance;if($('themeMode'))$('themeMode').value=state.settings.themeMode||'light';if($('backgroundColor'))$('backgroundColor').value=state.settings.backgroundColor||'#176fc9';if($('surfaceColor'))$('surfaceColor').value=state.settings.surfaceColor||'#eaf4ff';if($('fontColor'))$('fontColor').value=state.settings.fontColor||'#102c55';renderRecent();renderTransactions();renderWallets();renderBudget();renderGoals();renderReports();renderCalcHistory();renderTransferHistory();}
function txIcon(x){return (x.category||'📦').split(' ')[0]}
function txRow(x,actions=false){return `<div class="rowitem tx-row"><div class="catico">${txIcon(x)}</div><div class="grow tx-info"><b>${esc(x.note||x.category)}</b><small>${esc(x.category)}</small><small class="tx-date">${new Date(x.date+'T00:00:00').toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'})} · ${esc(state.wallets.find(w=>w.id===x.walletId)?.name||'Dompet dihapus')}</small></div><div class="tx-side"><div class="amount ${x.type==='income'?'positive':'negative'}">${x.type==='income'?'+':'−'}${rupiah(x.amount)}</div>${actions?`<div class="tx-actions"><button class="tx-action edit-action" onclick="editTx('${x.id}')">Edit</button><button class="tx-action delete-action" onclick="deleteTx('${x.id}')">Hapus</button></div>`:''}</div></div>`}
function renderRecent(){const a=[...state.tx].sort((x,y)=>(y.date||'').localeCompare(x.date||'')||(y.created||0)-(x.created||0)).slice(0,4);$('recentList').innerHTML=a.length?a.map(x=>txRow(x)).join(''):'<div class="empty">Belum ada transaksi. Catat pemasukan atau pengeluaran pertamamu.</div>'}
function setFilter(f,b){filter=f;document.querySelectorAll('#transactions .pill').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderTransactions()}
function renderTransactions(){if(!$('txList'))return;const q=($('searchTx').value||'').toLowerCase(),m=$('txMonth').value;const a=[...state.tx].sort((x,y)=>(y.date||'').localeCompare(x.date||'')||(y.created||0)-(x.created||0)).filter(x=>(filter==='all'||x.type===filter)&&(!m||monthKey(x.date)===m)&&(`${x.note} ${x.category}`).toLowerCase().includes(q));$('txList').innerHTML=a.length?a.map(x=>txRow(x,true)).join(''):'<div class="empty">Transaksi tidak ditemukan.</div>';}
function openTx(type='expense'){editing=null;txType=type;$('txTitle').textContent=type==='income'?'Tambah pemasukan':'Tambah pengeluaran';setMoneyInput($('txAmount'),'');$('txNote').value='';$('txDate').value=today();$('txCategory').innerHTML=cats[txType].map(x=>`<option>${x}</option>`).join('');$('txWallet').innerHTML=state.wallets.map(w=>`<option value="${w.id}">${esc(w.name)}</option>`).join('');chooseType(type);$('txModal').classList.add('show');setTimeout(()=>$('txAmount').focus(),100)}
function chooseType(t){txType=t;$('typeExpense').classList.toggle('active',t==='expense');$('typeIncome').classList.toggle('active',t==='income');$('txCategory').innerHTML=cats[t].map(x=>`<option>${x}</option>`).join('');$('txTitle').textContent=editing?'Edit transaksi':(t==='income'?'Tambah pemasukan':'Tambah pengeluaran')}
function closeModal(){$('txModal').classList.remove('show')}
function saveTx(){const amount=parseMoney($('txAmount').value),date=$('txDate').value||today();if(!Number.isSafeInteger(Math.round(amount))||amount<=0||amount>999999999999){toast('Nominal harus lebih dari 0 dan masuk akal');return}const w=state.wallets.find(x=>x.id===$('txWallet').value);if(!w){toast('Pilih dompet terlebih dahulu');return}const old=editing?state.tx.find(x=>x.id===editing):null;if(old){const ow=state.wallets.find(x=>x.id===old.walletId);if(ow)ow.balance+=(old.type==='income'?-Number(old.amount):Number(old.amount))}const x={id:editing||id(),type:txType,amount:Math.round(amount),category:$('txCategory').value,note:$('txNote').value.trim()||$('txCategory').value,date,walletId:w.id,created:old?.created||Date.now()};state.tx=state.tx.filter(z=>z.id!==editing);state.tx.push(x);w.balance+=(txType==='income'?x.amount:-x.amount);editing=null;closeModal();save();toast('Transaksi berhasil disimpan')}
function editTx(i){const x=state.tx.find(z=>z.id===i);if(!x)return;openTx(x.type);editing=i;$('txTitle').textContent='Edit transaksi';setMoneyInput($('txAmount'),x.amount);$('txNote').value=x.note;$('txDate').value=x.date;$('txWallet').value=x.walletId;$('txCategory').value=x.category}
function deleteTx(i){if(!confirm('Hapus transaksi ini? Saldo dompet akan disesuaikan.'))return;const x=state.tx.find(z=>z.id===i);if(!x)return;const w=state.wallets.find(z=>z.id===x.walletId);if(w)w.balance+=(x.type==='income'?-Number(x.amount):Number(x.amount));state.tx=state.tx.filter(z=>z.id!==i);save();toast('Transaksi dihapus')}
function renderWallets(){const list=$('walletList');if(!list)return;list.innerHTML=state.wallets.map(w=>`<div class="walletrow card"><div class="catico">${esc(w.emoji)}</div><div class="grow"><b>${esc(w.name)}</b><small>Saldo tersimpan</small></div><b>${rupiah(w.balance)}</b></div>`).join('');['transferFrom','transferTo'].forEach(k=>$(k).innerHTML=state.wallets.map(w=>`<option value="${w.id}">${esc(w.name)}</option>`).join(''))}
function addWallet(){const n=prompt('Nama dompet baru:');if(!n?.trim())return;const e=prompt('Emoji dompet (contoh 👛):','💳')||'💳';state.wallets.push({id:id(),name:n.trim().slice(0,35),emoji:e.slice(0,4),balance:0});save();toast('Dompet ditambahkan')}
function transfer(){const a=state.wallets.find(w=>w.id===$('transferFrom').value),b=state.wallets.find(w=>w.id===$('transferTo').value),v=parseMoney($('transferAmount').value);if(!a||!b||a.id===b.id||!(v>0)){toast('Periksa dompet dan nominal transfer');return}if(a.balance<v){toast('Saldo dompet asal tidak cukup');return}a.balance-=v;b.balance+=v;state.transfers.unshift({id:id(),from:a.id,to:b.id,amount:v,date:today(),created:Date.now()});setMoneyInput($('transferAmount'),'');save();toast('Transfer antar-dompet berhasil')}
function renderTransferHistory(){const el=$('transferHistory');if(!el)return;el.innerHTML=state.transfers.length?state.transfers.slice(0,12).map(t=>`<div class="rowitem"><div class="catico">⇄</div><div class="grow"><b>${esc(t.label||state.wallets.find(w=>w.id===t.from)?.name||'Dompet')} → ${esc(t.label?'Riwayat lama':(state.wallets.find(w=>w.id===t.to)?.name||'Dompet'))}</b><small>${new Date(t.date+'T00:00:00').toLocaleDateString('id-ID')}</small></div><b>${rupiah(t.amount)}</b></div>`).join(''):'<div class="empty">Riwayat transfer masih kosong.</div>'}
function monthExpense(category,month=monthKey()){return sum(state.tx.filter(x=>x.type==='expense'&&x.category===category&&monthKey(x.date)===month))}
function renderBudget(){const el=$('budgetList');if(!el)return;const m=monthKey();el.innerHTML=state.budgets.length?state.budgets.map(b=>{const used=monthExpense(b.category,m),pct=b.limit>0?Math.min(100,used/b.limit*100):0,over=used>b.limit;return `<div class="card budgetcard"><div class="budgettop"><b>${esc(b.category)}</b><span class="budgetactions"><button class="link" onclick="editBudget('${b.id}')">Ubah</button><button class="link dangerlink" onclick="removeBudget('${b.id}')">Hapus</button></span></div><div class="muted tiny">${rupiah(used)} dari ${rupiah(b.limit)}</div><div class="progress"><i class="${over?'over':''}" style="width:${pct}%"></i></div><div class="budgetfoot"><small class="${over?'negative':'muted'}">${Math.round(pct)}% terpakai${over?' · Melebihi batas':''}</small><small class="muted">${over?'Lebih '+rupiah(used-b.limit):'Sisa '+rupiah(b.limit-used)}</small></div></div>`}).join(''):'<div class="empty card">Belum ada anggaran. Buat batas pengeluaran per kategori agar lebih mudah mengontrol uang.</div>';const totalLimit=sum(state.budgets.map(b=>({amount:b.limit}))),totalUsed=sum(state.budgets.map(b=>({amount:monthExpense(b.category)})));$('budgetSummary').textContent=state.budgets.length?`${rupiah(totalUsed)} / ${rupiah(totalLimit)} digunakan bulan ini`:'Belum ada anggaran';$('budgetSummaryPage').textContent=`${rupiah(totalUsed)} / ${rupiah(totalLimit)} digunakan bulan ini`}
function openBudget(b=null){budgetEditing=b?.id||null;$('budgetCategory').innerHTML=cats.expense.map(c=>`<option>${c}</option>`).join('');$('budgetCategory').value=b?.category||cats.expense[0];setMoneyInput($('budgetLimit'),b?.limit||'');$('budgetTitle').textContent=b?'Ubah anggaran':'Tambah anggaran';$('budgetModal').classList.add('show')}
function addBudget(){openBudget()}
function editBudget(i){const b=state.budgets.find(x=>x.id===i);if(b)openBudget(b)}
function closeBudget(){ $('budgetModal').classList.remove('show');budgetEditing=null }
function saveBudget(){const category=$('budgetCategory').value,limit=parseMoney($('budgetLimit').value);if(!(limit>0)){toast('Masukkan batas anggaran yang benar');return}const existing=state.budgets.find(b=>b.id===budgetEditing||b.category===category);if(existing){existing.category=category;existing.limit=limit}else state.budgets.push({id:id(),category,limit});closeBudget();save();toast('Anggaran tersimpan')}
function removeBudget(i){if(!confirm('Hapus anggaran kategori ini?'))return;state.budgets=state.budgets.filter(x=>x.id!==i);save()}
function renderGoals(){const el=$('goalList');if(!el)return;el.innerHTML=state.goals.length?state.goals.map(g=>{const pct=g.target>0?Math.min(100,g.saved/g.target*100):0;return `<div class="card goalcard"><div class="budgettop"><b>🎯 ${esc(g.name)}</b><span><button class="link" onclick="contribute('${g.id}')">＋ Isi</button><button class="link dangerlink" onclick="reduceGoal('${g.id}')">− Kurangi</button><button class="link dangerlink" onclick="removeGoal('${g.id}')">Hapus</button></span></div><div class="muted tiny">${rupiah(g.saved)} / ${rupiah(g.target)}</div><div class="progress"><i style="width:${pct}%"></i></div><small class="muted">${Math.round(pct)}% tercapai · Sisa target ${rupiah(Math.max(0,g.target-g.saved))}</small></div>`}).join(''):'<div class="empty card">Belum ada target tabungan. Buat target agar progres menabung terlihat.</div>'}
function addGoal(){const n=prompt('Nama target tabungan:');if(!n?.trim())return;const v=Math.round(Number(prompt('Target nominal (Rp):')));if(!(v>0))return;state.goals.push({id:id(),name:n.trim().slice(0,45),target:v,saved:0});save();toast('Target tabungan dibuat')}
function contribute(i){const g=state.goals.find(x=>x.id===i);if(!g)return;const v=Math.round(Number(prompt(`Tambah tabungan untuk ${g.name} (Rp):`)));if(!(v>0))return;g.saved+=v;save();toast('Progres tabungan diperbarui')}
function reduceGoal(i){const g=state.goals.find(x=>x.id===i);if(!g)return;const raw=prompt(`Kurangi tabungan ${g.name}. Saldo saat ini ${rupiah(g.saved)}. Masukkan nominal yang dikurangi (Rp):`);if(raw===null)return;const v=parseMoney(raw);if(!(v>0)){toast('Masukkan nominal pengurangan yang benar');return}if(v>g.saved){toast('Pengurangan melebihi saldo tabungan');return}g.saved-=v;save();toast('Saldo tabungan berhasil dikurangi')}
function removeGoal(i){if(!confirm('Hapus target tabungan ini?'))return;state.goals=state.goals.filter(g=>g.id!==i);save()}
function chart(el,vals,labels){$(el).innerHTML=vals.map((v,i)=>`<div class="barcol"><div class="bar" style="height:${Math.max(4,Math.round(v/(Math.max(...vals,1))*105))}px"></div><small>${esc(labels[i])}</small></div>`).join('')}
function monthLabel(key){const [y,m]=key.split('-').map(Number);return new Date(y,m-1,1).toLocaleDateString('id-ID',{month:'long',year:'numeric'})}
function monthTotals(key){return {income:sum(txOf('income',key)),expense:sum(txOf('expense',key))}}
function openReportMonth(key){reportMonthSelected=key;renderReports()}
function backReportMonths(){reportMonthSelected=null;renderReports()}
function renderReports(){
 const now=new Date(),keys=[];
 for(let k=11;k>=0;k--){const d=new Date(now.getFullYear(),now.getMonth()-k,1);keys.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`)}
 const allKeys=[...new Set([...keys,...state.tx.map(x=>monthKey(x.date))])].sort().reverse().slice(0,24);
 const list=$('reportMonthList'),detail=$('reportMonthDetail');
 if(!list||!detail)return;
 if(!reportMonthSelected){$('reportHeading').textContent='Laporan';list.classList.remove('hidden');detail.classList.add('hidden');$('reportPeriod').textContent='12 bulan terakhir';
  list.innerHTML=allKeys.map(key=>{const t=monthTotals(key),net=t.income-t.expense,total=t.income+t.expense,ip=total?Math.round(t.income/total*100):0,ep=total?100-ip:0;return `<button class="month-report-row" onclick="openReportMonth('${key}')"><b class="month-report-title">${esc(monthLabel(key))}</b><div class="month-report-body"><div class="mini-donut" style="--income-p:${ip}%;--expense-p:${ep}%"></div><div class="month-report-values"><div><span>Pemasukan:</span><b class="positive">${rupiah(t.income)}</b></div><div><span>Pengeluaran:</span><b class="negative">${rupiah(-t.expense)}</b></div><div><span>Total:</span><b class="${net>=0?'positive':'negative'}">${rupiah(net)}</b></div></div></div></button>`}).join('');
 }else{
  $('reportHeading').textContent='Diagram';list.classList.add('hidden');detail.classList.remove('hidden');const key=reportMonthSelected,t=monthTotals(key),net=t.income-t.expense;
  $('reportPeriod').textContent=monthLabel(key);
  const map={};state.tx.filter(x=>x.type==='expense'&&monthKey(x.date)===key).forEach(x=>map[x.category]=(map[x.category]||0)+Number(x.amount));
  const entries=Object.entries(map).sort((a,b)=>b[1]-a[1]);const total=t.expense;const palette=['#ef514d','#159fe8','#43ad68','#f59e0b','#f3d34a','#8b72dc','#16b8b0','#e879a7','#64748b','#a87945'];
  let cursor=0;const stops=entries.map(([cat,val],i)=>{const pct=total?val/total*100:0,from=cursor;cursor+=pct;return `${palette[i%palette.length]} ${from.toFixed(2)}% ${cursor.toFixed(2)}%`});
  const donut=$('reportDonut');donut.style.background=entries.length?`conic-gradient(${stops.join(',')})`:'conic-gradient(#dce8f5 0% 100%)';
  $('reportDonutCenter').innerHTML=`<b>${rupiah(total)}</b><small>Total pengeluaran</small>`;
  $('reportCategoryLegend').innerHTML=entries.length?entries.map(([cat,val],i)=>`<div class="report-legend-row"><i style="background:${palette[i%palette.length]}"></i><span>${esc(cat)}</span><b>${total?Math.round(val/total*100):0}%</b><strong>${rupiah(-val)}</strong></div>`).join(''):'<div class="empty">Belum ada pengeluaran pada bulan ini.</div>';
  $('detailIncome').textContent=rupiah(t.income);$('detailExpense').textContent=rupiah(t.expense);$('detailNet').textContent=rupiah(net);$('detailNet').className=net>=0?'positive':'negative';
 }
 const recent=allKeys.slice(0,6).reverse(),vals=recent.map(k=>monthTotals(k).expense),labels=recent.map(k=>new Date(Number(k.slice(0,4)),Number(k.slice(5))-1,1).toLocaleDateString('id-ID',{month:'short'}));chart('homeChart',vals.slice(-5),labels.slice(-5));
}
// Safe arithmetic parser; no eval/Function execution.
function evaluateExpression(input){const s=input.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');if(!/^[0-9+\-*/().\s]+$/.test(s))throw Error('invalid');const tokens=s.match(/\d+(?:\.\d+)?|[()+\-*/]/g)||[];let p=0;function expr(){let v=term();while(tokens[p]==='+'||tokens[p]==='-'){const op=tokens[p++],r=term();v=op==='+'?v+r:v-r}return v}function term(){let v=factor();while(tokens[p]==='*'||tokens[p]==='/'){const op=tokens[p++],r=factor();v=op==='*'?v*r:v/r}return v}function factor(){if(tokens[p]==='-'){p++;return -factor()}if(tokens[p]==='+'){p++;return factor()}if(tokens[p]==='('){p++;const v=expr();if(tokens[p++]!==')')throw Error('paren');return v}const n=Number(tokens[p++]);if(!Number.isFinite(n))throw Error('number');return n}const result=expr();if(p!==tokens.length||!Number.isFinite(result))throw Error('invalid');return result}
const keys=['7','8','9','÷','4','5','6','×','1','2','3','−','0','.','%','+','⌫','C','(',')','='];
function initCalc(){$('calcKeys').innerHTML=keys.map(k=>`<button class="${'÷×−+'.includes(k)?'op':''} ${k==='='?'equal':''}" onclick="calcKey('${k}')">${k}</button>`).join('')}
function calcKey(k){if(k==='C'){calcClear();return}if(k==='⌫'){calcExpr=calcExpr.slice(0,-1)}else if(k==='='){calculate();return}else{if(calcJust&&!'+−×÷%'.includes(k))calcExpr='';calcExpr+=k;calcJust=false}updateCalc()}
function calcClear(){calcExpr='';calcResult=0;calcJust=false;updateCalc()}
function formatCalcNumber(value){const n=Number(value);if(!Number.isFinite(n))return String(value);return new Intl.NumberFormat('id-ID',{maximumFractionDigits:8,useGrouping:true}).format(n)}
function formatCalcExpression(expr){return String(expr||'').replace(/\d+(?:\.\d+)?/g,m=>formatCalcNumber(m))}
function updateCalc(){$('calcDisplay').textContent=calcExpr?formatCalcExpression(calcExpr):'0'}
function calculate(){try{const v=evaluateExpression(calcExpr);calcResult=v;state.calcHistory.unshift({expr:calcExpr,result:v});state.calcHistory=state.calcHistory.slice(0,15);calcExpr=String(Number(v.toFixed(8)));calcJust=true;updateCalc();renderCalcHistory();localStorage.setItem(KEY,JSON.stringify(state))}catch{$('calcDisplay').textContent='Periksa hitungan';setTimeout(updateCalc,1000)}}
function renderCalcHistory(){$('calcHistory').innerHTML=state.calcHistory.length?state.calcHistory.map(x=>`<div class="rowitem"><div class="grow"><b>${esc(formatCalcExpression(x.expr))}</b><small>Hasil perhitungan</small></div><b>${esc(formatCalcNumber(x.result))}</b></div>`).join(''):'<div class="empty">Belum ada riwayat kalkulator.</div>'}
function useCalc(){let v=calcJust?calcResult:0;if(!calcJust){try{v=evaluateExpression(calcExpr)}catch{v=0}}if(!(Number(v)>0)){toast('Hitung nominal positif terlebih dahulu');return}go('transactions');openTx('expense');setMoneyInput($('txAmount'),Math.round(v));toast('Hasil kalkulator dimasukkan ke pengeluaran')}
function download(blob,name){if(window.AndroidBridge&&window.AndroidBridge.saveFile){const reader=new FileReader();reader.onload=()=>{const data=String(reader.result).split(',')[1]||'';window.AndroidBridge.saveFile(data,name,blob.type||'application/octet-stream')};reader.readAsDataURL(blob);return}const a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1500)}
function backup(){download(new Blob([JSON.stringify({app:'BiruFinance',version:3,exportedAt:new Date().toISOString(),data:state},null,2)],{type:'application/json'}),`BiruFinance-Backup-${today()}.json`);toast('File backup dibuat')}
function shareBackup(){const data=JSON.stringify({app:'BiruFinance',version:3,exportedAt:new Date().toISOString(),data:state},null,2);if(window.BiruNative)BiruNative.shareText(data);else backup()}
function restore(ev){const f=ev.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const parsed=JSON.parse(r.result);let x=parsed.data||parsed;if(!Array.isArray(x.wallets)&&Array.isArray(x.tx))x=migrateOldFormat(x);if(!Array.isArray(x.wallets)||!Array.isArray(x.tx))throw Error('bad');if(confirm('Pulihkan data dari backup? Data saat ini akan diganti.')){state={...defaults(),...x,settings:{...defaults().settings,...x.settings}};save();toast('Backup berhasil dipulihkan')}}catch{toast('File backup tidak valid atau rusak')} };r.readAsText(f);ev.target.value=''}
function exportCSV(){const rows=[['Tanggal','Jenis','Kategori','Catatan','Nominal','Dompet'],...state.tx.map(x=>[x.date,x.type,x.category,x.note,x.amount,state.wallets.find(w=>w.id===x.walletId)?.name||''])];const csv=rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');download(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}),`BiruFinance-Transaksi-${today()}.csv`);toast('Ekspor CSV siap')}
function resetData(){if(confirm('Hapus semua transaksi, dompet, anggaran, dan target tabungan? Sebaiknya simpan backup dahulu.')){state=defaults();save();toast('Data aplikasi direset')}}
function applyAppearance(){const root=document.documentElement,mode=state.settings.themeMode||'light';root.dataset.theme=mode;root.style.setProperty('--custom-bg',state.settings.backgroundColor||'#176fc9');root.style.setProperty('--custom-surface',state.settings.surfaceColor||'#eaf4ff');root.style.setProperty('--custom-font',state.settings.fontColor||'#102c55');const dark=mode==='dark'||(mode==='system'&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches);root.classList.toggle('dark-mode',!!dark)}
function updateAppearance(){state.settings.themeMode=$('themeMode').value;state.settings.backgroundColor=$('backgroundColor').value;state.settings.surfaceColor=$('surfaceColor').value;state.settings.fontColor=$('fontColor').value;save();toast('Tampilan berhasil diperbarui')}
function resetAppearance(){state.settings.themeMode='light';state.settings.backgroundColor='#176fc9';state.settings.surfaceColor='#eaf4ff';state.settings.fontColor='#102c55';save();toast('Warna bawaan dipulihkan')}
if(window.matchMedia){const mq=window.matchMedia('(prefers-color-scheme: dark)');mq.addEventListener?.('change',()=>{if(state.settings.themeMode==='system')applyAppearance()})}
function toggleBalance(){state.settings.hideBalance=$('hideToggle').checked;save()}

let smartReview=[],lastSmartImageData="";
function smartSetStatus(message){const el=$('smartStatus');if(el)el.textContent=message}
function smartReadImage(event){
 const file=event.target.files&&event.target.files[0];if(!file)return;
 const preview=$('smartPreview'),wrap=$('smartPreviewWrap');if(preview&&wrap){preview.src=URL.createObjectURL(file);wrap.classList.remove('hidden')}
 if(file.size>12*1024*1024){smartSetStatus('Ukuran gambar maksimal 12 MB.');return}
 if(!window.AndroidBridge||!AndroidBridge.recognizeImage){smartSetStatus('OCR offline memerlukan APK Android 3.6.0.');return}
 smartSetStatus('Sedang membaca gambar secara offline…');
 const reader=new FileReader();
 reader.onload=()=>{lastSmartImageData=String(reader.result||'');AndroidBridge.recognizeImage(lastSmartImageData)};
 reader.onerror=()=>smartSetStatus('Gambar gagal dibaca.');
 reader.readAsDataURL(file);
}
function smartRetake(){['smartCamera','smartGallery'].forEach(k=>{const e=$(k);if(e)e.value=''});$('smartPreviewWrap')?.classList.add('hidden');smartSetStatus('Silakan ambil foto atau pilih gambar lain.');}
window.onSmartOcrResult=function(text){$('smartText').value=text||'';smartSetStatus('Pembacaan selesai. Periksa teks, lalu tekan “Baca & analisis teks”.');};
window.onSmartOcrError=function(message){smartSetStatus('OCR gagal: '+message);};
function smartGuessCategory(line,type){
 const t=line.toLowerCase();
 if(type==='income'){
  if(/gaji|salary|upah/.test(t))return '💼 Gaji';
  if(/bonus|thr/.test(t))return '🧾 Bonus';
  if(/jual|penjualan|jualan/.test(t))return '🛒 Penjualan';
  if(/hadiah|gift/.test(t))return '🎁 Hadiah';
  if(/investasi|dividen/.test(t))return '📈 Investasi';
  return '💰 Lainnya';
 }
 if(/makan|minum|kopi|jajan|resto|warung|bakso/.test(t))return /kopi|jajan/.test(t)?'☕ Jajan':'🍜 Makanan';
 if(/bensin|bbm|parkir|ojek|transport|tol/.test(t))return '🚗 Transportasi';
 if(/belanja|supermarket|market|toko|online|shopee/.test(t))return '🛍 Belanja';
 if(/listrik|air|internet|wifi|tagihan|pulsa/.test(t))return '💡 Tagihan';
 if(/rumah|kontrak|sewa/.test(t))return '🏠 Rumah';
 if(/obat|dokter|klinik|kesehatan/.test(t))return '💊 Kesehatan';
 if(/game|film|hiburan/.test(t))return '🎮 Hiburan';
 if(/sekolah|buku|kursus/.test(t))return '📚 Pendidikan';
 return '📦 Lainnya';
}
function smartParseText(){
 const text=$('smartText').value||'';
 if(!text.trim()){smartSetStatus('Masukkan teks atau pindai gambar terlebih dahulu.');return}
 const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 const out=[];
 for(const line of lines){
  const dateMatch=line.match(/\b(20\d{2})[-/](\d{1,2})[-/](\d{1,2})\b/);
  const amountLine=line.replace(/\b20\d{2}[-/]\d{1,2}[-/]\d{1,2}\b/g,' ');
  const matches=[...amountLine.matchAll(/(?:rp\s*)?(\d[\d.,\s]{1,})(?:\s*(?:rupiah|idr))?/ig)];
  if(!matches.length)continue;
  let raw=matches[matches.length-1][1].replace(/\s/g,'');
  let amount=Number(raw.replace(/[.,]/g,''));if(!Number.isFinite(amount)||amount<=0||amount>999999999999)continue;
  const type=/gaji|pemasukan|diterima|transfer masuk|penjualan|bonus|income|refund|top.?up/.test(line.toLowerCase())?'income':'expense';
  const date=dateMatch?`${dateMatch[1]}-${String(dateMatch[2]).padStart(2,'0')}-${String(dateMatch[3]).padStart(2,'0')}`:today();
  const note=line.replace(/(?:rp\s*)?\d[\d.,\s]{1,}(?:\s*(?:rupiah|idr))?/ig,'').replace(/\b20\d{2}[-/]\d{1,2}[-/]\d{1,2}\b/,'').replace(/[-:|]/g,' ').trim()||'Smart Import';
  const category=smartGuessCategory(line,type);
  const duplicate=state.tx.some(x=>x.amount===amount&&x.type===type&&x.date===date&&String(x.note||'').toLowerCase()===note.toLowerCase());
  out.push({type,amount,date,note,category,duplicate,selected:!duplicate});
 }
 smartReview=out;
 smartRenderRows();
 smartSetStatus(out.length?`${out.length} kandidat transaksi ditemukan. Periksa sebelum menyimpan.`:'Belum menemukan nominal yang dikenali. Coba foto lebih jelas atau tempel teks manual.');
}
function smartRenderRows(){
 const wrap=$('smartRows');if(!wrap)return;
 $('smartReview').classList.toggle('hidden',!smartReview.length);
 wrap.innerHTML=smartReview.map((x,i)=>`<div class="smart-row ${x.duplicate?'duplicate':''}">
  <label><input type="checkbox" data-smart-check="${i}" ${x.selected?'checked':''}> Pilih transaksi ${x.duplicate?'· kemungkinan duplikat':''}</label>
  <div class="smart-row-grid">
   <div class="field"><label>Jenis</label><select data-smart-type="${i}"><option value="expense" ${x.type==='expense'?'selected':''}>Pengeluaran</option><option value="income" ${x.type==='income'?'selected':''}>Pemasukan</option></select></div>
   <div class="field"><label>Nominal (Rp)</label><input inputmode="numeric" data-smart-amount="${i}" value="${esc(formatMoneyValue(x.amount))}"></div>
   <div class="field"><label>Kategori</label><select data-smart-category="${i}">${cats[x.type].map(c=>`<option ${c===x.category?'selected':''}>${esc(c)}</option>`).join('')}</select></div>
   <div class="field"><label>Tanggal</label><input type="date" data-smart-date="${i}" value="${esc(x.date)}"></div>
  </div>
  <div class="field"><label>Catatan</label><input data-smart-note="${i}" value="${esc(x.note)}"></div>
 </div>`).join('');
}
function smartClear(){smartReview=[];$('smartReview').classList.add('hidden');$('smartRows').innerHTML='';}
function smartSaveAll(){
 let count=0,duplicates=0;
 smartReview.forEach((x,i)=>{
  const check=document.querySelector(`[data-smart-check="${i}"]`);if(!check?.checked)return;
  const type=document.querySelector(`[data-smart-type="${i}"]`).value;
  const amount=parseMoney(document.querySelector(`[data-smart-amount="${i}"]`).value);
  const category=document.querySelector(`[data-smart-category="${i}"]`).value;
  const date=document.querySelector(`[data-smart-date="${i}"]`).value||today();
  const note=document.querySelector(`[data-smart-note="${i}"]`).value.trim()||category;
  if(!amount||amount>999999999999)return;
  const duplicate=state.tx.some(t=>t.amount===amount&&t.type===type&&t.date===date&&String(t.note||'').toLowerCase()===note.toLowerCase());
  if(duplicate){duplicates++;return}
  const wallet=state.wallets[0];if(!wallet)return;
  state.tx.push({id:id(),type,amount,category,note,date,walletId:wallet.id,created:Date.now()});
  wallet.balance+=(type==='income'?amount:-amount);count++;
 });
 if(count){save();smartClear();$('smartText').value='';toast(`${count} transaksi berhasil diimpor${duplicates?`; ${duplicates} duplikat dilewati`:''}`)}
 else toast(duplicates?'Transaksi duplikat dilewati.':'Tidak ada transaksi valid yang dipilih.');
}

window.handleAndroidBack=()=>{if($('txModal').classList.contains('show')){closeModal();return true}if($('budgetModal').classList.contains('show')){closeBudget();return true}if(activePage!=='home'){go('home');return true}return false};
document.addEventListener('touchstart',e=>{swipeStart=e.changedTouches[0].clientX},{passive:true});document.addEventListener('touchend',e=>{if(swipeStart===null)return;const dx=e.changedTouches[0].clientX-swipeStart;swipeStart=null;if(Math.abs(dx)<95)return;const pages=['home','transactions','budget','savings','reports','calculator'];let i=pages.indexOf(activePage);if(i<0)return;const next=Math.max(0,Math.min(pages.length-1,i+(dx<0?1:-1)));if(next!==i)go(pages[next])},{passive:true});
['txAmount','budgetLimit','transferAmount'].forEach(k=>bindMoneyInput($(k)));initCalc();render();setTimeout(()=>{const splash=$('splash');if(splash)splash.classList.add('hide')},1200);setTimeout(()=>{if(!sessionStorage.getItem('bf_intro')){sessionStorage.setItem('bf_intro','1');if(state.settings.sound){const a=$('introAudio');a.volume=.38;a.play().catch(()=>beep())}}},280);
