package com.birufinance.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class QuickAddWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int widgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_quick_add);
            views.setOnClickPendingIntent(R.id.widget_income, makeIntent(context, "income", widgetId * 10 + 1));
            views.setOnClickPendingIntent(R.id.widget_expense, makeIntent(context, "expense", widgetId * 10 + 2));
            manager.updateAppWidget(widgetId, views);
        }
    }

    private PendingIntent makeIntent(Context context, String type, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setAction("com.birufinance.app.QUICK_ADD_" + type.toUpperCase());
        intent.putExtra(MainActivity.EXTRA_WIDGET_ACTION, type);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
