# Checklist uji Biru Finance 3.0

## Build dan instalasi
- [ ] Jalankan GitHub Actions dan pastikan `assembleDebug` sukses.
- [ ] Unduh artifact `BiruFinance-3.0.0-debug-APK` dan instal APK pada Android 6+.
- [ ] Pastikan ikon berlian, splash animation, soundtrack, dan dashboard tampil benar.
- [ ] Pastikan aplikasi dapat dibuka tanpa koneksi internet.

## Transaksi dan saldo
- [ ] Tambah pemasukan dan pastikan saldo dompet bertambah.
- [ ] Tambah pengeluaran dan pastikan saldo dompet berkurang.
- [ ] Edit transaksi pada dompet yang sama dan dompet berbeda; pastikan saldo diperbarui satu kali.
- [ ] Hapus transaksi dan pastikan saldo dikembalikan.
- [ ] Uji tanggal transaksi dan ringkasan bulan berjalan.
- [ ] Uji pencarian dan filter pemasukan/pengeluaran.

## Dompet, anggaran, tabungan
- [ ] Tambah dompet dan transfer saldo antar-dompet.
- [ ] Pastikan transfer tidak mengubah total saldo gabungan.
- [ ] Tambah, ubah, dan hapus anggaran; uji status saat melewati batas.
- [ ] Buat target tabungan, tambah kontribusi, dan hapus target.

## Laporan dan alat
- [ ] Periksa laporan, selisih bersih, grafik enam bulan, dan kategori pengeluaran.
- [ ] Uji kalkulator operasi dasar, persentase, dan penggunaan hasil ke transaksi.
- [ ] Ekspor CSV ke folder Download.
- [ ] Buat backup JSON, pulihkan dari file, dan pastikan data kembali.
- [ ] Uji pemulihan file backup dari versi BiruFinance lama.
- [ ] Uji sembunyikan nominal, efek suara, dan getaran.
- [ ] Uji navigasi swipe, navigasi bawah, tombol kembali Android, dan rotasi/ukuran layar.

## Catatan
- [ ] Uji di perangkat fisik dan catat setiap bug sebelum menandai rilis stabil.

- [ ] Calculator formats thousands with Indonesian grouping (e.g. 1.500.000) and decimal comma.
- [ ] Font color picker applies to text throughout the app and persists after restart.


## Widget Android 2×2 (versi 3.4.0)
- [ ] Widget BiruFinance muncul di daftar widget launcher.
- [ ] Widget dapat ditempatkan dengan ukuran awal 2×2.
- [ ] Tombol Pemasukan membuka formulir dengan jenis Pemasukan terpilih.
- [ ] Tombol Pengeluaran membuka formulir dengan jenis Pengeluaran terpilih.
- [ ] Setelah formulir disimpan, saldo dan daftar transaksi diperbarui.
- [ ] Widget dapat dipakai ketika aplikasi sebelumnya tertutup maupun berjalan.


## Smart Import 3.5.0
- [ ] Pilih foto galeri dan ambil foto melalui kamera.
- [ ] OCR berjalan offline setelah APK terpasang.
- [ ] Teks hasil OCR dapat diedit sebelum analisis.
- [ ] Beberapa transaksi dapat dikenali dari banyak baris.
- [ ] Nominal, kategori, tanggal, jenis, dan catatan dapat dikoreksi.
- [ ] Kandidat duplikat ditandai dan tidak tersimpan otomatis.
- [ ] Transaksi baru memperbarui saldo, laporan, anggaran, dan riwayat.
- [ ] Uji struk cetak, screenshot transfer, dan tulisan tangan dengan catatan akurasi.


## Hybrid Smart Import 3.6.0
- [ ] OCR ML Kit tetap berjalan tanpa internet.
- [ ] Tombol AI tulisan tangan meminta konfirmasi sebelum upload.
- [ ] Endpoint non-HTTPS ditolak.
- [ ] Endpoint kosong menampilkan petunjuk konfigurasi.
- [ ] Proxy mengharuskan token akses yang benar.
- [ ] Proxy meneruskan gambar ke Cloud Vision DOCUMENT_TEXT_DETECTION.
- [ ] Hasil cloud mengisi kolom teks, bukan langsung menyimpan transaksi.
- [ ] Pengguna dapat mengedit hasil sebelum impor.
- [ ] Error jaringan, token salah, dan OCR kosong ditampilkan dengan pesan yang wajar.
- [ ] Foto tidak dikirim kecuali pengguna menekan tombol AI online dan menyetujui dialog.
