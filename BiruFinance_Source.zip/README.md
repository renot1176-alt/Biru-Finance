# Biru Finance — Android APK via GitHub Actions

Proyek Android WebView offline untuk Biru Finance. Build APK dilakukan oleh GitHub Actions; tidak perlu Android Studio, Sketchware, atau komputer lokal.

## Isi
- `app/src/main/assets/index.html`: aplikasi pengatur keuangan offline.
- `app/src/main/java/.../MainActivity.java`: pembungkus Android WebView.
- `.github/workflows/build-apk.yml`: workflow otomatis untuk membuat APK debug.

## Cara build hanya dengan HP Android
1. Unduh ZIP proyek ini dan ekstrak di HP, atau gunakan menu upload file di GitHub.
2. Masuk ke https://github.com dan login/buat akun.
3. Buat repository baru bernama `Biru-Finance`. Untuk kemudahan, pilih **Public** (atau Private jika ingin source tetap pribadi; kuota Actions gratis memiliki batas penggunaan).
4. Upload seluruh ISI folder proyek ini ke root repository. Pastikan folder `.github/workflows` ikut terunggah. Jika GitHub mobile tidak menampilkan folder tersembunyi, buat folder dan file workflow melalui tampilan web desktop atau unggah ZIP melalui fitur yang tersedia.
5. Buka tab **Actions** di repository.
6. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
7. Pilih workflow **Build Biru Finance APK** lalu tekan **Run workflow**. Workflow juga berjalan otomatis setiap ada push ke branch `main`.
8. Tunggu sampai tanda centang hijau muncul.
9. Buka hasil run yang selesai, gulir ke **Artifacts**, lalu unduh `Biru-Finance-APK`.
10. Ekstrak ZIP artifact. Di dalamnya ada `app-debug.apk`. Buka file itu untuk memasang aplikasi.

## Catatan
- Ini APK debug untuk pemasangan pribadi dan pengujian, bukan rilis Play Store.
- APK debug ditandatangani dengan debug key otomatis oleh Android Gradle Plugin.
- Data transaksi disimpan di penyimpanan lokal WebView pada HP. Backup JSON tetap disarankan.
- Build pertama dapat memerlukan beberapa menit.
- Jika build gagal, buka run yang gagal dan periksa bagian log **Build APK**.
