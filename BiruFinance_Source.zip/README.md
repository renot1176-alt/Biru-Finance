# Biru Finance — Android APK via GitHub Actions

Proyek Android WebView offline untuk Biru Finance. Build APK dilakukan oleh GitHub Actions; tidak perlu Android Studio, Sketchware, atau komputer lokal.

## Isi
- `app/src/main/assets/index.html`: aplikasi pengatur keuangan offline dengan dashboard Liquid Glass, navigasi swipe, dan soundtrack pembuka.
- `app/src/main/java/.../MainActivity.java`: pembungkus Android WebView (termasuk izin playback soundtrack otomatis).
- `.github/workflows/build-apk.yml`: workflow otomatis untuk membuat APK debug.

## Cara build hanya dengan HP Android
1. Unduh ZIP proyek ini dan ekstrak di HP, atau gunakan menu upload file di GitHub.
2. Masuk ke https://github.com dan login/buat akun.
3. Buat repository baru bernama `Biru-Finance`. Untuk kemudahan, pilih **Public** (atau Private jika ingin source tetap pribadi; kuota Actions gratis memiliki batas penggunaan).
4. Upload seluruh ISI folder proyek ini ke root repository. Pastikan folder `.github/workflows` ikut terunggah. Jika GitHub mobile tidak menampilkan folder tersembunyi, buat folder dan file workflow melalui tampilan web desktop atau unggah ZIP melalui fitur yang tersedia.
5. Pastikan folder `.github/workflows/build-apk.yml` ikut terunggah. Build menggunakan Gradle 8.9 dari GitHub Actions, jadi Gradle wrapper tidak wajib ada di ZIP ini.\n6. Buka tab **Actions** di repository.
7. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
8. Pilih workflow **Build Biru Finance APK** lalu tekan **Run workflow**. Workflow juga berjalan otomatis setiap ada push ke branch `main`.
9. Tunggu sampai tanda centang hijau muncul.
10. Buka hasil run yang selesai, gulir ke **Artifacts**, lalu unduh `Biru-Finance-APK`.
11. Ekstrak ZIP artifact. Di dalamnya ada `app-debug.apk`. Buka file itu untuk memasang aplikasi.

## Catatan
- Ini APK debug untuk pemasangan pribadi dan pengujian, bukan rilis Play Store.
- APK debug ditandatangani dengan debug key otomatis oleh Android Gradle Plugin.
- Data transaksi disimpan di penyimpanan lokal WebView pada HP. Backup JSON tetap disarankan.
- Build pertama dapat memerlukan beberapa menit.
- Jika build gagal, buka run yang gagal dan periksa bagian log **Build APK**.


## Catatan revisi versi 1.1
- Modal transaksi ditampilkan di atas navigasi bawah dan tombol Simpan tetap mudah dijangkau.
- Navigasi bawah diperbesar dan dibuat bergaya kapsul kaca; halaman dapat digeser horizontal pada area konten.
- Dashboard memakai proporsi kartu, logo, tombol, dan teks yang lebih besar.
- Musik pembuka orisinal dicoba diputar otomatis saat splash tampil. Perangkat Android/WebView dapat tetap membatasi autoplay berdasarkan kebijakan sistem; tombol suara tersedia untuk mematikan atau menyalakannya.
- Tanggal transaksi menggunakan tanggal lokal perangkat.
- Data lama menggunakan key localStorage yang sama agar tidak sengaja di-reset oleh pembaruan tampilan.
